#include "../include/cdata.h"
#include "../include/cthread.h"
#include "../include/support.h"
#include <stdlib.h>

PFILA2 pFilap0 = NULL;

void initReadyQueue()
{
	pFilap0 = malloc(sizeof(PFILA2));
	CreateFila2(pFilap0);
}

/* retorna -1 se der erro
retorn 0 se conseguir
*/
int addThreadToReadyQueue(PFILA2 pfila, TCB_t *thread)
{
	thread->state = 1; //Muda o estado da thread para apto
	TCB_t *tcb_it;	
	// pfile vazia?
	if (FirstFila2(pfila)==0)
	{
		do 
		{
			tcb_it = (TCB_t *) GetAtIteratorFila2(pfila);
			if (thread->prio < tcb_it->prio)
			{
				return InsertBeforeIteratorFila2(pfila, thread);
			}
		} while (NextFila2(pfila)==0);
	}	
	return SUCCESS;
}

/*
TCB_t *getNextThreadToExecute():

se conseguir retorna uma a thread de acordo com a prioridade dela
se não conseguir retorna null;
*/
TCB_t *getNextThreadToExecute()
{
	PFILA2 firstNotEmptyQueue;

	if(FirstFila2(pFilap0) == 0)
	{
		firstNotEmptyQueue = pFilap0;
	}
	else
	{
		return NULL;
	}
	TCB_t *threadToLeave;
	threadToLeave = GetAtIteratorFila2(firstNotEmptyQueue);
	DeleteAtIteratorFila2(firstNotEmptyQueue);
	return threadToLeave;
}


TCB_t *removeThreadFromReadyQueue(int tid)
{
	TCB_t * ThreadToRemove;
	if(FirstFila2(pFilap0) == SUCCESS)
	{
		do
		{
			ThreadToRemove = GetAtIteratorFila2(pFilap0);
			if(ThreadToRemove->tid == tid)
			{
				DeleteAtIteratorFila2(pFilap0);
				return ThreadToRemove;
			}
		}while(NextFila2(pFilap0) == SUCCESS);
	} 
	return NULL;
}
