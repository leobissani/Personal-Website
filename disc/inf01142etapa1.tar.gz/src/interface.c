#include <string.h>

#include "../include/cdata.h"
#include "../include/cthread.h"
#include "../include/semaphore.h"
#include "../include/ready_queue.h"
#include "../include/execution_queue.h"
#include "../include/blocking_queue.h"
#include "../include/short_scheduler.h"
#include "../include/medium_scheduler.h"
#include "../include/long_scheduler.h"

int initialized = 0;

void initialize()
{
	initialized = 1;
	initReadyQueue();
	initBlockingQueue();
	initLongScheduler();
	initializeSemaphores();
}

int ccreate (void *(*start)(void*), void *arg, int a)
{
	if(initialized == 0)
	{
		initialize();
	}
	return createNewThread(start, arg);
}

int cyield(void)
{
	if(initialized == 0)
	{
		initialize();
	}
	return executeNextThread();
}

int cjoin(int tid)
{
	if(initialized == 0)
	{
		initialize();
	}
	return waitOnThread(tid);
}

int csem_init(csem_t *sem, int count)
{
	if(initialized == 0)
	{
		initialize();
	}
	return newSemaphore(sem, count);
}

int cwait(csem_t *sem)
{
	if(initialized == 0)
	{
		initialize();
	}
	return waitOnSemaphore(sem);
}

int csignal(csem_t *sem)
{
	if(initialized == 0)
	{
		initialize();
	}
	return releaseSemaphore(sem);
}

int cidentify (char *name, int size)
{
	if(size < sizeof("205680 Juliano Nakamura\n220485 Leonardo Bissani\n208783 Paulo Ricardo Delwing\n"))
	{
		return ERROR;
	}
	strcpy(name, "205680 Juliano Nakamura\n220485 Leonardo Bissani\n208783 Paulo Ricardo Delwing\n");
	return SUCCESS;
}
