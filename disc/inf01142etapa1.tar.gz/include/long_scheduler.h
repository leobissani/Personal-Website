#include "cdata.h"
#include "ready_queue.h"
#include "semaphore.h"
#include <ucontext.h>
#include <stdlib.h>

int createNewThread(void *context, void *arg);
void initLongScheduler();
int finishedThread(int tid);
