#include "cdata.h"

TCB_t *BlockCurrentThread();
int UnblockThread(int tid);
