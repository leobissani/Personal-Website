#include "cdata.h"

int AddThreadToBlockingQueue(TCB_t *thread);
TCB_t *RemoveThreadFromBlockingQueue(int tid);
void initBlockingQueue();
