function coord22(imagem2, ponto)

    x = ponto(1);
    y = ponto(2);
    
    h13 = 96.5855;
    h12 = -9.2697;
    h11 = 30.997;
    h23 = 17.2925;
    h22 = 23.8245;
    h21 = 11.2965;
    
    u = (h11 * x) + (h12 * y) + h13;
    v = (h21 * x) + (h22 * y) + h23;

    u
    v
    
    figure(2), imshow(imagem2), hold on
    plot([u,u],[v,v],'x','LineWidth',4,'Color','green');

end

