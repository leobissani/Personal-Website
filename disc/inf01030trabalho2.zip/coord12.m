function coord12(imagem2, ponto)

    x = ponto(1);
    y = ponto(2);
    
    h13 = 39.1834;
    h12 = -2.8415;
    h11 = 33.9917;
    h23 = 24.0837;
    h22 = 31.2274;
    h21 = 2.4490;
    
    u = (h11 * x) + (h12 * y) + h13;
    v = (h21 * x) + (h22 * y) + h23;

    u
    v
    
    figure(2), imshow(imagem2), hold on
    plot([u,u],[v,v],'x','LineWidth',4,'Color','green');

end


