function imagemresultado = binarizacao(arquivo)

% imagem = imread(arquivo);
imagem = arquivo;
imagemOriginal = imagem;
imagem = double(imagem);
imagemresultado = imagem;
[N, M] = size(imagem);

T = 0;
varT = 1;
maior = 0;
menor = 255;
menormedia = 0;
maiormedia = 0;
menorcontador = 0;
maiorcontador = 0;

for i = 1 : N-1
    for j = 1 : M-1
		if (imagem(i,j) < menor)
			menor = imagem(i,j);
		else
			if (imagem(i,j) > maior)
				maior = imagem(i,j);
			end
		end
	end
end

T = (maior + menor)/2;

while(varT >= 1 || varT <= -1)
	for i = 1 : N-1
		for j = 1 : M-1
			if(imagem(i,j) <= T)
				menormedia = menormedia + imagem(i,j);
				menorcontador = double(menorcontador + 1);
				imagemresultado(i,j) = 0;
			else
				if(imagem(i,j) > T)
					maiormedia = double(maiormedia) + double(imagem(i,j));
					maiorcontador = double(maiorcontador + 1);
					imagemresultado(i,j) = 255;
				end
			end
		end
    end
    
    menormedia = menormedia/menorcontador;
	maiormedia = maiormedia/maiorcontador;
	varT = T;
	T = (menormedia + maiormedia)/2;
    varT = T - varT;
end

figure(1), imshow(imagemOriginal);
figure(2), imshow(imagemresultado);

end

