function filtroMedia(arquivo, arquivotxt)

matrizfiltro = dlmread(arquivotxt);
imagem = imread(arquivo);
imagem = double(imagem);
imagemresultado = imagem;
[N, M] = size(imagem);

    for i = 1 : N-1
        for j = 1 : M-1
            pixelmedia = 0;
            contador0 = 0;
            contadorfiltro = matrizfiltro(i,j);

            if contadorfiltro == 1
                imagemresultado(i,j) = imagem(i,j);
            else
                if mod(contadorfiltro,2) == 0
                    for k = i-(floor(contadorfiltro/2)-1) : (i+floor(contadorfiltro/2))
                        for l = j-(floor(contadorfiltro/2)-1): (j+floor(contadorfiltro/2))
                            if((k < N && l< M) && (k > 0 && l > 0))
                                pixelmedia = pixelmedia + imagem(k,l);
								contador0 = contador0 + 1;
                            end
                        end
                    end
                    
                    imagemresultado(i,j) = pixelmedia/contador0;
                    
                else
                    for k = (i-floor(contadorfiltro/2)) : (i+floor(contadorfiltro/2))
                        for l = (j-floor(contadorfiltro/2)) : (j+floor(contadorfiltro/2))
                            if((k < N && l< M) && (k > 0 && l > 0))
                                pixelmedia = pixelmedia + imagem(k,l);
								contador0 = contador0 + 1;
                            end
                        end
                    end
                    
                    imagemresultado(i,j) = pixelmedia/contador0;
                    
                end
            end
        end
    end
    
    imagem = uint8(imagem);
    figure(1), imshow(imagem);
    imagemresultado = uint8(imagemresultado);
    figure(2), imshow(imagemresultado);
    
end
