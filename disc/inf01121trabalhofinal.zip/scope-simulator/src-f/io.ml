open Core;;
open Types;;
open Stacks;;
open Helpers;;

let outputs = ref [];;

let print_list lst = 
  List.iter ~f:(fun x -> 
    print_string (sprintf "%s\n" x)
  ) lst;;

let rec print_program program tgt line =
  match program with
  | hd :: tl ->
    let id = (if tgt = line then "*" else " ") in
    print_string (sprintf "%s %d\t%s\n" id line hd);
    print_program tl tgt (line+1)
  | _ -> ();;

let print x = 
  outputs := !outputs @ [x];
  print_string x;;

let print_variables vars = 
  List.iter ~f:(fun v ->
    match v with 
    | VARIABLE (id, value, _) -> print_string (sprintf "\tvar %s = %d\n" id value)
    | FUNCTION (id, _, _) -> print_string (sprintf "\tfunction %s\n" id)
  ) vars

let rec _print_stack stack pos = 
  if pos < 0 then () else (
    let frame = get_content (List.nth stack pos) in
    print_string (sprintf "\n------- frame %d -------\n" pos);
    print_variables (List.rev frame.vars);
    print_string (sprintf "VD\t%d\n" frame.vd);
    print_string (sprintf "VE\t%d\n" frame.ve);
    print_string (sprintf "RET\t%d\n" frame.ret);
    print_string (sprintf "------------------------");
    _print_stack stack (pos - 1));;

let print_stack stack = _print_stack stack ((List.length stack) - 1);;

let print_and_wait stack program curr_line =
  print_string "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
  print_stack stack;
  print_string "\n";
  print_program program curr_line 0;
  print_string "\n";
  print_list !outputs;
  Out_channel.(flush stdout); 
  ignore In_channel.(input_line_exn stdin);;