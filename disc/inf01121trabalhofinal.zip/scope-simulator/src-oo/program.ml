open Core;;
open Core_kernel__.Import;;

class program filename = object
  val lines : string array = List.to_array (In_channel.read_lines filename)
  val mutable curr : int = 0

  method go_to (n : int) : unit = curr <- n
  method get_line_number : int = curr

  method get_line : string = 
    if curr < Array.length lines then (
      curr <- curr + 1; lines.(curr - 1) 
    ) else "EOF"

  method print : unit = 
    for i = 0 to Array.length lines - 1 do
      let mark = if (i = curr) then ("*") else (" ") in
      print_string (sprintf "%s %d\t%s\n" mark i lines.(i))
    done
end