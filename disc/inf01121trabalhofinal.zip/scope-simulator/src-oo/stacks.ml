open Core

exception UndeclaredVariableError;;

type var =
  | VARIABLE of string * int       (* identificador, valor *)
  | FUNCTION of string * int * int (* identificador, inicio, pai estatico *)

type scopes =
  | DYNAMIC
  | STATIC

let get_var_content x =
  match x with
  | Some v -> v
  | None -> raise UndeclaredVariableError;;

(* Classe para encapsular acesso a dados de variáveis e funções *)
class variable v def = object
  val v : var = v
  val def : int = def

  method get_def_line : int = def

  method get_id : string =
    match v with
    | VARIABLE (id, _) -> id
    | FUNCTION (id, _, _) -> id

  method get_value : int option =
    match v with
    | VARIABLE (_, value) -> Some value
    | _ -> None

  method get_start : int option =
    match v with
    | FUNCTION (_, start, _) -> Some start
    | _ -> None

  method get_pe : int option =
    match v with
    | FUNCTION (_, _, pe) -> Some pe
    | _ -> None

  method print : unit =
    match v with
    | VARIABLE (id, value) -> print_string (sprintf "\tvar %s = %d\n" id value)
    | FUNCTION (id, _, _) -> print_string (sprintf "\tfunction %s\n" id)
end

(* Frame *)
class frame ret_ ve_ vd_ = object
  val ret : int = ret_
  val ve : int = ve_
  val vd : int = vd_
  val mutable vars : variable array = [| |]

  method get_ret = ret
  method get_ve = ve
  method get_vd = vd
  method get_vars = vars

  (* Adiciona variável ao frame *)
  method set_var (v : variable) : unit = vars <- Array.append vars [| v |]
  (* Retorna a variável com identificador `id` ou None *)
  method get_var (id : string) : variable option =
    let found = ref false in
    let i = ref 0 in
    while !i < Array.length vars && not !found do
      if vars.(!i)#get_id = id then found := true;
      if not !found then i := !i + 1
    done;
    if !i < Array.length vars then (
      Some (vars.(!i))
    ) else None

  (* Imprime o frame *)
  method print : unit=
    print_string (sprintf "\n---------------\n");
    for i = (Array.length vars) - 1 downto 0 do
      vars.(i)#print
    done;
    print_string (sprintf "VD\t%d\n" vd);
    print_string (sprintf "VE\t%d\n" ve);
    print_string (sprintf "RET\t%d\n" ret);
    print_string (sprintf "---------------")
end

(* Representação abstrata de uma pilha *)
class virtual _stack = object
  val mutable frames : frame array =
    (* inicializa lista de frames com o frame `main` *)
    let f = new frame (-1) (-1) (-1) in
    [| f |]

  method n_of_frames : int = Array.length frames
  method virtual get_var : string -> variable
  (* Adiciona variável ao último frame *)
  method set_var (var : var) (def : int) : unit =
    let idx = ((Array.length frames) - 1) in
    let f = ref frames.(idx) in
    !f#set_var (new variable var def);
    frames.(idx) <- !f

  (* Empilha novo frame *)
  method push_frame (ret : int) (ve : int) : unit =
    let vd = (Array.length frames) - 1 in
    frames <- Array.append frames [| (new frame ret ve vd) |]

  (* Desempilha frame e retorna endereço de retorno *)
  method pop_frame : int =
    let i = (Array.length frames) - 1 in
    let ret = (frames.(i))#get_ret in
    frames <- Array.slice frames 0 i;
    ret

  (* Imprime a pilha *)
  method print : unit =
    for i = Array.length frames - 1 downto 0 do
      frames.(i)#print
    done
end

(* Pilha para escopo dinâmico *)
class dstack = object
  inherit _stack

  (* Retorna a variável `id` a partir de escopo dinâmico *)
  method get_var (id : string) : variable =
    let i = ref ((Array.length frames) - 1) in
    let var = ref None in
    while !var = None do
      var := frames.(!i)#get_var id;
      if !var = None then i := frames.(!i)#get_vd
      (* TODO: verificar se o i -1 dá problema *)
    done;
    get_var_content !var
end

(* Pilha para escopo estático *)
class sstack = object
  inherit _stack

  (* limitante para busca de variável
  se a variável encontrada tiver sido definida em linha após
  o a linha limitante, então ela deve ser desconsiderada *)
  val mutable limiter : int = -1
  method set_limiter (limit : int) : unit = (limiter <- limit)

  (* Retorna a variável `id` a partir de escopo estático *)
  method get_var (id : string) : variable =
    let i = ref ((Array.length frames) - 1) in
    let var = ref None in
    while !var = None do
      var := frames.(!i)#get_var id;
      if !var = None then i := frames.(!i)#get_ve
    done;
    let v = get_var_content !var in
    if (v#get_def_line < limiter)
    then (v) else (raise UndeclaredVariableError)
end

(* Delegate para pilhas *)
class stack scope = object

  val scope = (match String.lowercase scope with
  | "s" | "static" -> STATIC
  | "d" | "dynamic" -> DYNAMIC
  | _ -> DYNAMIC)
  val ds = new dstack
  val ss = new sstack

  method get_scope : scopes = scope

  method get_var (var : string) (line : int) : variable =
    match scope with
    | STATIC -> ss#set_limiter line; ss#get_var var
    | DYNAMIC -> ds#get_var var

  method n_of_frames : int =
    match scope with
    | STATIC -> ss#n_of_frames
    | DYNAMIC -> ds#n_of_frames

  method set_var (var : var) (def : int) : unit =
    match scope with
    | STATIC -> ss#set_var var def
    | DYNAMIC -> ds#set_var var def

  method push_frame (ret : int) (ve : int) : unit =
    match scope with
    | STATIC -> ss#push_frame ret ve
    | DYNAMIC -> ds#push_frame ret ve

  method pop_frame : int =
    match scope with
    | STATIC -> ss#pop_frame
    | DYNAMIC -> ds#pop_frame

  method print : unit =
    match scope with
    | STATIC -> ss#print
    | DYNAMIC -> ds#print
end
